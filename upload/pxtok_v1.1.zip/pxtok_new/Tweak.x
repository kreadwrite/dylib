#import "TikTokHeaders.h"
#import "Settings/PXAssets.h"
#import "Settings/PXMenuTabBarController.h"
#import <UserNotifications/UserNotifications.h>
#import <CoreText/CoreText.h>

NSArray *jailbreakPaths;

static void showConfirmation(void (^okHandler)(void)) {
  [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"Вы уверены?" : @"Are you sure?") image:nil actionButtonTitle:([BHIManager isRussian] ? @"Да" : @"Yes") cancelButtonTitle:([BHIManager isRussian] ? @"Нет" : @"No") actionBlock:^{
    okHandler();
  } cancelBlock:nil];
}

static void PXTranslateText(NSString *text) {
    if (text.length == 0) return;
    NSString *encoded = [text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    // sl=auto detects the source language automatically; change tl=ru to your preferred target language
    NSString *urlString = [NSString stringWithFormat:@"https://translate.google.com/?sl=auto&tl=ru&text=%@&op=translate", encoded];
    NSURL *url = [NSURL URLWithString:urlString];
    if (url) {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

// Ghost: schedules the clipboard to be wiped a short while after PXTok copies
// something into it, so a copied link/description/comment doesn't linger
// indefinitely in your clipboard (visible to any app that reads it, including
// the system clipboard-access popup on iOS 14+).
static void PXScheduleClipboardClear(void) {
    if (![BHIManager ghostClipboardClear]) return;
    NSString *snapshot = [UIPasteboard generalPasteboard].string;
    double delay = 30.0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // Only clear if the clipboard still holds exactly what we put there —
        // don't stomp on something the user copied from elsewhere in the meantime.
        if ([[UIPasteboard generalPasteboard].string isEqualToString:snapshot]) {
            [UIPasteboard generalPasteboard].string = @"";
        }
    });
}

// Precise badge hook using TTKBadgeImpl confirmed in MusicallyCore binary v46.0.0.
// This intercepts the central badge-count update method that drives all tab-bar red dots.
%hook TTKBadgeImpl
- (void)setBadgeCount:(NSInteger)count {
    if ([BHIManager hideNotificationBadges]) {
        %orig(0);
    } else {
        %orig(count);
    }
}
- (void)showBadge {
    if (![BHIManager hideNotificationBadges]) {
        %orig;
    }
}
%end

%hook AWETabBarPlusButton
- (void)layoutSubviews {
    %orig;
    if ([BHIManager hidePlusButton]) {
        self.hidden = YES;
        self.alpha = 0;
    }
}
%end

%hook UITextField
- (BOOL)becomeFirstResponder {
    if ([BHIManager oledKeyboard]) {
        self.keyboardAppearance = UIKeyboardAppearanceDark;
    }
    return %orig;
}
%end

%hook UITextView
- (BOOL)becomeFirstResponder {
    if ([BHIManager oledKeyboard]) {
        self.keyboardAppearance = UIKeyboardAppearanceDark;
    }
    return %orig;
}
%end

// Precise hook on the real emoji-bar class found via class-dump of MusicallyCore
// (TTKCommentEmoticonsBar, property emojiBarEnable confirmed in binary)
%hook TTKCommentEmoticonsBar
- (void)setEmojiBarEnable:(BOOL)enable {
    if ([BHIManager hideEmojiPanel]) {
        %orig(NO);
    } else {
        %orig(enable);
    }
}
%end

// Precise DM read-receipt hook using TIMConversationReadManagerImpl found in binary
// This is the class that actually dispatches markConversationAsRead to the server.
%hook TIMConversationReadManagerImpl
- (void)markConversationAsRead:(id)conversation completion:(id)completion {
    if ([BHIManager disableReadReceipt]) {
        // Swallow the call — read index is not sent to server, so the sender
        // never receives "seen" confirmation. All message content still arrives
        // locally; this only suppresses the outgoing read-status event.
        return;
    }
    %orig;
}
- (void)markConversationAsRead:(id)conversation {
    if ([BHIManager disableReadReceipt]) {
        return;
    }
    %orig;
}
%end

%hook AppDelegate
- (_Bool)application:(UIApplication *)application didFinishLaunchingWithOptions:(id)arg2 {
    %orig;
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"flex_enebaled"]) {
        [[%c(FLEXManager) performSelector:@selector(sharedManager)] performSelector:@selector(showExplorer)];
    }
    if (![[NSUserDefaults standardUserDefaults] objectForKey:@"PXTokFirstRun"]) {
        [[NSUserDefaults standardUserDefaults] setValue:@"PXTokFirstRun" forKey:@"PXTokFirstRun"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"hide_ads"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"download_button"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"remove_elements_button"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"show_porgress_bar"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"save_profile"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"copy_profile_information"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"extended_bio"];
        [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"extendedComment"];
    }
    [BHIManager cleanCache];

    if ([BHIManager hidePlusButton] || [BHIManager hideNotificationBadges]) {
        // NOTE: best-effort generic approach — repeatedly scans the visible view
        // hierarchy for tab-bar buttons/badges by class-name and accessibility-label
        // pattern matching, since the exact tab bar classes aren't in TikTokHeaders.h
        // yet. Verify the real classes via class-dump for a more reliable %hook.
        // Throttled to 2.5s (was 1s) — still responsive after navigation without
        // unnecessarily burning CPU/battery on a constant 1Hz view-tree walk.
        [NSTimer scheduledTimerWithTimeInterval:2.5 repeats:YES block:^(NSTimer * _Nonnull timer) {
            UIWindow *keyWindow = [UIApplication sharedApplication].windows.firstObject;
            [self pxScanForTabBarElementsIn:keyWindow];
        }];
    }
    return true;
}
%new - (void)pxScanForTabBarElementsIn:(UIView *)root {
    for (UIView *subview in root.subviews) {
        NSString *className = NSStringFromClass([subview class]).lowercaseString;

        if ([BHIManager hidePlusButton] && [subview isKindOfClass:[UIButton class]] &&
            ([subview.accessibilityLabel.lowercaseString isEqualToString:@"create"] ||
             [subview.accessibilityLabel.lowercaseString containsString:@"plus"])) {
            subview.hidden = YES;
        }

        if ([BHIManager hideNotificationBadges] &&
            ([className containsString:@"badge"] || [className containsString:@"reddot"] || [className containsString:@"dot"])) {
            subview.hidden = YES;
        }
        [self pxScanForTabBarElementsIn:subview];
    }
}
static BOOL isAuthenticationShowed = FALSE;
- (void)applicationDidBecomeActive:(id)arg1 { // old app lock TODO: add face-id
  %orig;

  if ([BHIManager appLock] && !isAuthenticationShowed) {
    UIViewController *rootController = [[self window] rootViewController];
    SecurityViewController *securityViewController = [SecurityViewController new];
    securityViewController.modalPresentationStyle = UIModalPresentationOverFullScreen;
    [rootController presentViewController:securityViewController animated:YES completion:nil];
    isAuthenticationShowed = TRUE;
  }

  // Usage stats: mark the start of a new active session.
  [[NSUserDefaults standardUserDefaults] setDouble:[[NSDate date] timeIntervalSince1970] forKey:@"px_session_start"];
  NSInteger totalSessions = [[NSUserDefaults standardUserDefaults] integerForKey:@"px_total_sessions"];
  [[NSUserDefaults standardUserDefaults] setInteger:totalSessions + 1 forKey:@"px_total_sessions"];
}

- (void)applicationWillEnterForeground:(id)arg1 {
  %orig;
  isAuthenticationShowed = FALSE;

  if ([BHIManager ghostPrivacyScreen]) {
    UIWindow *keyWindow = [UIApplication sharedApplication].windows.firstObject;
    UIView *blurView = [keyWindow viewWithTag:987654];
    if (blurView) {
        [UIView animateWithDuration:0.15 animations:^{
            blurView.alpha = 0;
        } completion:^(BOOL finished) {
            [blurView removeFromSuperview];
        }];
    }
  }
}

- (void)applicationWillResignActive:(id)arg1 {
  %orig;
  // Usage stats: fold this session's duration into the running total.
  double start = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_session_start"];
  if (start > 0) {
      double elapsed = [[NSDate date] timeIntervalSince1970] - start;
      double totalSeconds = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_total_seconds"];
      [[NSUserDefaults standardUserDefaults] setDouble:totalSeconds + elapsed forKey:@"px_total_seconds"];
      [[NSUserDefaults standardUserDefaults] setDouble:0 forKey:@"px_session_start"];

      // Also fold into "today"'s bucket, resetting if the day rolled over.
      NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
      formatter.dateFormat = @"yyyy-MM-dd";
      NSString *todayKey = [formatter stringFromDate:[NSDate date]];
      NSString *storedDay = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_stats_day"];
      double todaySeconds = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_today_seconds"];
      if (![storedDay isEqualToString:todayKey]) {
          todaySeconds = 0;
          [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"px_today_videos"];
          [[NSUserDefaults standardUserDefaults] setValue:todayKey forKey:@"px_stats_day"];
      }
      [[NSUserDefaults standardUserDefaults] setDouble:todaySeconds + elapsed forKey:@"px_today_seconds"];
  }

  // Ghost: blur your own screen content before the app switcher snapshot is taken,
  // so nobody nearby can see your feed/DMs in the multitasking preview.
  if ([BHIManager ghostPrivacyScreen]) {
    UIWindow *keyWindow = [UIApplication sharedApplication].windows.firstObject;
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    blurView.tag = 987654;
    blurView.frame = keyWindow.bounds;
    blurView.alpha = 0;
    [keyWindow addSubview:blurView];
    [UIView animateWithDuration:0.15 animations:^{
        blurView.alpha = 1;
    }];
  }
}
%end

%hook NSUserActivity
- (void)setEligibleForSearch:(BOOL)eligibleForSearch {
    if ([BHIManager ghostHideFromSpotlight]) {
        %orig(NO); // never let TikTok content get indexed into device-wide Spotlight search
    } else {
        %orig;
    }
}
%end

%hook UINavigationBar
- (void)didMoveToWindow {
    %orig;
    if ([BHIManager transparentNavBar]) {
        [self setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        self.shadowImage = [UIImage new];
        self.translucent = YES;
        self.backgroundColor = [UIColor clearColor];
    }
}
%end

%hook UIImpactFeedbackGenerator
- (instancetype)initWithStyle:(UIImpactFeedbackStyle)style {
    NSString *strength = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_haptic_strength"];
    if ([BHIManager hapticsAdjustEnabled] && strength.length > 0) {
        if ([strength isEqualToString:@"off"]) {
            // We can't truly "remove" impacts once the generator exists without
            // also hooking impactOccurred; off is enforced there too, see below.
        } else if ([strength isEqualToString:@"light"]) {
            style = UIImpactFeedbackStyleLight;
        } else if ([strength isEqualToString:@"medium"]) {
            style = UIImpactFeedbackStyleMedium;
        } else if ([strength isEqualToString:@"strong"]) {
            style = UIImpactFeedbackStyleHeavy;
        }
    }
    return %orig(style);
}
- (void)impactOccurred {
    NSString *strength = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_haptic_strength"];
    if ([BHIManager hapticsAdjustEnabled] && [strength isEqualToString:@"off"]) {
        return; // swallow the haptic entirely
    }
    %orig;
}
%end

%hook TTKMediaSpeedControlService
- (void)setPlaybackRate:(CGFloat)arg1 {
    NSNumber *speed = [BHIManager selectedSpeed];
    if (![BHIManager speedEnabled] || [speed isEqualToNumber:@1]) {
        return %orig;
    }
    if ([BHIManager speedEnabled]) {
        if ([BHIManager selectedSpeed]) {
            return %orig([speed floatValue]);
        }
    } else {
        return %orig;
    }
}
%end

%hook AWEUserWorkCollectionViewCell
- (void)configWithModel:(id)arg1 isMine:(BOOL)arg2 { // Video like count & upload date lables
    %orig;
    if ([BHIManager videoLikeCount] || [BHIManager videoUploadDate]) {
        for (int i = 0; i < [[self.contentView subviews] count]; i ++) {
            UIView *j = [[self.contentView subviews] objectAtIndex:i];
            if (j.tag == 1001) {
                [j removeFromSuperview];
            } 
            else if (j.tag == 1002) {
                [j removeFromSuperview];
            }
        }

        AWEAwemeModel *model = [self model];
        AWEAwemeStatisticsModel *statistics = [model statistics];
        NSNumber *createTime = [model createTime];
        NSNumber *likeCount = [statistics diggCount];
        NSString *likeCountFormatted = [self formattedNumber:[likeCount integerValue]];
        NSString *formattedDate = [self formattedDateStringFromTimestamp:[createTime doubleValue]];

        UILabel *likeCountLabel = [UILabel new];
        likeCountLabel.text = likeCountFormatted;
        likeCountLabel.textColor = [UIColor whiteColor];
        likeCountLabel.font = [UIFont boldSystemFontOfSize:13.0];
        likeCountLabel.tag = 1001;
        [likeCountLabel setTranslatesAutoresizingMaskIntoConstraints:false];
        
        UIImageView *heartImage = [UIImageView new];
        heartImage.image = [UIImage systemImageNamed:@"heart"];
        heartImage.tintColor = [UIColor whiteColor];
        [heartImage setTranslatesAutoresizingMaskIntoConstraints:false];

        UILabel *uploadDateLabel = [UILabel new];
        uploadDateLabel.text = formattedDate;
        uploadDateLabel.textColor = [UIColor whiteColor];
        uploadDateLabel.font = [UIFont boldSystemFontOfSize:13.0];
        uploadDateLabel.tag = 1002;
        [uploadDateLabel setTranslatesAutoresizingMaskIntoConstraints:false];

        UIImageView *clockImage = [UIImageView new];
        clockImage.image = [UIImage systemImageNamed:@"clock"];
        clockImage.tintColor = [UIColor whiteColor];
        [clockImage setTranslatesAutoresizingMaskIntoConstraints:false];
        

        for (int i = 0; i < [[self.contentView subviews] count]; i ++) {
            UIView *j = [[self.contentView subviews] objectAtIndex:i];
            if (j.tag == 1001) {
                [j removeFromSuperview];
            } 
            else if (j.tag == 1002) {
                [j removeFromSuperview];
            }
        }
        if ([BHIManager videoLikeCount]) {
        [self.contentView addSubview:heartImage];
        [NSLayoutConstraint activateConstraints:@[
                [heartImage.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:110],
                [heartImage.leadingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.leadingAnchor constant:4],
                [heartImage.widthAnchor constraintEqualToConstant:16],
                [heartImage.heightAnchor constraintEqualToConstant:16],
            ]];
        [self.contentView addSubview:likeCountLabel];
        [NSLayoutConstraint activateConstraints:@[
                [likeCountLabel.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:109],
                [likeCountLabel.leadingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.leadingAnchor constant:23],
                [likeCountLabel.widthAnchor constraintEqualToConstant:200],
                [likeCountLabel.heightAnchor constraintEqualToConstant:16],
            ]];
        }
        if ([BHIManager videoUploadDate]) {
        [self.contentView addSubview:clockImage];
        [NSLayoutConstraint activateConstraints:@[
                [clockImage.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:128],
                [clockImage.leadingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.leadingAnchor constant:4],
                [clockImage.widthAnchor constraintEqualToConstant:16],
                [clockImage.heightAnchor constraintEqualToConstant:16],
            ]];
        [self.contentView addSubview:uploadDateLabel];
        [NSLayoutConstraint activateConstraints:@[
                [uploadDateLabel.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:127],
                [uploadDateLabel.leadingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.leadingAnchor constant:23],
                [uploadDateLabel.widthAnchor constraintEqualToConstant:200],
                [uploadDateLabel.heightAnchor constraintEqualToConstant:16],
            ]];
        }
    }
}
%new - (NSString *)formattedNumber:(NSInteger)number {

    if (number >= 1000000) {
        return [NSString stringWithFormat:@"%.1fm", number / 1000000.0];
    } else if (number >= 1000) {
        return [NSString stringWithFormat:@"%.1fk", number / 1000.0];
    } else {
        return [NSString stringWithFormat:@"%ld", (long)number];
    }

}
%new - (NSString *)formattedDateStringFromTimestamp:(NSTimeInterval)timestamp {

    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamp];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateFormat = @"dd.MM.yy"; 
    return [dateFormatter stringFromDate:date];

}
%end

%hook TTKProfileRootView
- (void)layoutSubviews { // Video count
    %orig;
    if ([BHIManager profileVideoCount]){
        TTKProfileOtherViewController *rootVC = [self yy_viewController];
        AWEUserModel *user = [rootVC user];
        NSNumber *userVideoCount = [user visibleVideosCount];
        if (userVideoCount){
            UILabel *userVideoCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(0,2,100,20.5)];
            userVideoCountLabel.text = [NSString stringWithFormat:@"Video Count: %@", userVideoCount];
            userVideoCountLabel.font = [UIFont systemFontOfSize:9.0];
            [self addSubview:userVideoCountLabel];
        }
    }
}
%end

%hook BDImageView
- (void)layoutSubviews { // Profile save
    %orig;
    if ([BHIManager profileSave]) {
        [self addHandleLongPress];
    }
}
%new - (void)addHandleLongPress {
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = 0.3;
    [self addGestureRecognizer:longPress];
}
%new - (void)handleLongPress:(UILongPressGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateBegan) {
        [%c(AWEUIAlertView) showAlertWithTitle:@"Save profile image" description:@"Do you want to save this image" image:nil actionButtonTitle:@"Yes" cancelButtonTitle:@"No" actionBlock:^{
            UIImageWriteToSavedPhotosAlbum([self bd_baseImage], self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
  } cancelBlock:nil];
    }
}
%new - (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error) {
        NSLog(@"Error saving image: %@", error.localizedDescription);
    } else {
        NSLog(@"Image successfully saved to Photos app");
    }
}
%end

%hook AWEUserNameLabel // stub — fake verification removed
- (void)layoutSubviews {
    %orig;
}
%end

%hook TTTAttributedLabel // copy profile decription
- (void)layoutSubviews {
    %orig;
    if ([BHIManager profileCopy]){
        [self addHandleLongPress];
    }
}
%new - (void)addHandleLongPress {
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = 0.3;
    [self addGestureRecognizer:longPress];
}
%new - (void)handleLongPress:(UILongPressGestureRecognizer *)sender {
    if (sender.state == UIGestureRecognizerStateBegan) {
        NSString *profileDescription = [self text];
        [%c(AWEUIAlertView) showAlertWithTitle:@"Copy bio" description:@"Do you want to copy this text to clipboard" image:nil actionButtonTitle:@"Yes" cancelButtonTitle:@"No" actionBlock:^{
             if (profileDescription) {
                                                                    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
                                                                    pasteboard.string = profileDescription;
                                                                }
  } cancelBlock:nil];
    }
}
%end

%hook TTKSettingsBaseCellPlugin
- (void)didSelectItemAtIndex:(NSInteger)index {
    if ([self.itemModel.identifier isEqualToString:@"pxtok_settings"]) {
        PXMenuTabBarController *menu = [[PXMenuTabBarController alloc] init];
        menu.modalPresentationStyle = UIModalPresentationFormSheet;
        [topMostController() presentViewController:menu animated:YES completion:nil];
    } else {
        return %orig;
    }
}
%end

%hook AWESettingsNormalSectionViewModel
// viewDidLoad может вызываться повторно при возврате на экран — поэтому
// вставляем только если PXTok-ячейки ещё нет в списке моделей.
- (void)viewDidLoad {
    %orig;
    [self pxInsertPXTokCellIfNeeded];
}
- (void)viewWillAppear:(BOOL)animated {
    %orig;
    [self pxInsertPXTokCellIfNeeded];
}
%new - (void)pxInsertPXTokCellIfNeeded {
    if (![self.sectionIdentifier isEqualToString:@"account"]) return;
    // Проверяем, есть ли уже PXTok-модель
    for (id model in self.cellPlugins) {
        if ([model respondsToSelector:@selector(itemModel)]) {
            id item = [model itemModel];
            if ([item respondsToSelector:@selector(identifier)] &&
                [[item identifier] isEqualToString:@"pxtok_settings"]) {
                return; // уже есть — не дублируем
            }
        }
    }
    TTKSettingsBaseCellPlugin *cell = [[%c(TTKSettingsBaseCellPlugin) alloc] initWithPluginContext:self.context];
    AWESettingItemModel *item = [[%c(AWESettingItemModel) alloc] initWithIdentifier:@"pxtok_settings"];
    [item setTitle:@"PXTok"];
    [item setDetail:@"PXTok"];
    [item setIconImage:[PXAssets pxIcon]];
    [item setType:99];
    [cell setItemModel:item];
    [self insertModel:cell atIndex:0 animated:NO];
}
%end

%hook SparkViewController // alwaysOpenSafari
- (void)viewWillAppear:(BOOL)animated {
    if (![BHIManager alwaysOpenSafari]) {
        return %orig;
    }
    
    // NSURL *url = self.originURL;
    NSURLComponents *components = [NSURLComponents componentsWithURL:self.originURL resolvingAgainstBaseURL:NO];
    NSString *searchParameter = @"url";
    NSString *searchValue = nil;
    
    for (NSURLQueryItem *queryItem in components.queryItems) {
        if ([queryItem.name isEqualToString:searchParameter]) {
            searchValue = queryItem.value;
            break;
        }
    }
    
    // In-app browser is used for two-factor authentication with security key,
    // login will not complete successfully if it's redirected to Safari
    // if ([urlStr containsString:@"twitter.com/account/"] || [urlStr containsString:@"twitter.com/i/flow/"]) {
    //     return %orig;
    // }

    if (searchValue) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:searchValue] options:@{} completionHandler:nil];
        [self didTapCloseButton];
    } else {
        return %orig;
    }
}
%end

%hook CTCarrier // changes country 
- (NSString *)mobileCountryCode {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"mcc"];
        }
        return %orig;
    }
    return %orig;
}

- (void)setIsoCountryCode:(NSString *)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig(selectedRegion[@"code"]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}

- (NSString *)isoCountryCode {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}

- (NSString *)mobileNetworkCode {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"mnc"];
        }
        return %orig;
    }
    return %orig;
}
%end
%hook TTKStoreRegionService
- (id)storeRegion {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (id)getStoreRegion {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (void)setStoreRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig([selectedRegion[@"code"] lowercaseString]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
%end
%hook TIKTOKRegionManager
+ (NSString *)systemRegion {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
+ (id)region {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
+ (id)mccmnc {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [NSString stringWithFormat:@"%@%@", selectedRegion[@"mcc"], selectedRegion[@"mnc"]];
        }
        return %orig;
    }
    return %orig;
}
+ (id)storeRegion {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
+ (id)currentRegionV2 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
+ (id)localRegion {
        if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}

%end

%hook TTKPassportAppStoreRegionModel
- (id)storeRegion {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (void)setStoreRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig([selectedRegion[@"code"] lowercaseString]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
- (void)setLocalizedCountryName:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig(selectedRegion[@"name"]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
- (id)localizedCountryName {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"name"];
        }
        return %orig;
    }
    return %orig;
}
%end

%hook ATSRegionCacheManager
- (id)getRegion {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (id)storeRegionFromCache {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (id)storeRegionFromTTNetNotification:(id)arg1 {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
- (void)setRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig([selectedRegion[@"code"] lowercaseString]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
- (id)region {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return [selectedRegion[@"code"] lowercaseString];
        }
        return %orig;
    }
    return %orig;
}
%end

%hook TTKStoreRegionModel
- (id)storeRegion {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
- (void)setStoreRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig(selectedRegion[@"code"]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
%end

%hook TTInstallIDManager
- (id)currentAppRegion {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
- (void)setCurrentAppRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig(selectedRegion[@"code"]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
%end

%hook BDInstallGlobalConfig
- (id)currentAppRegion {
 if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return selectedRegion[@"code"];
        }
        return %orig;
    }
    return %orig;
}
- (void)setCurrentAppRegion:(id)arg1 {
    if ([BHIManager regionChangingEnabled]) {
        if ([BHIManager selectedRegion]) {
            NSDictionary *selectedRegion = [BHIManager selectedRegion];
            return %orig(selectedRegion[@"code"]);
        }
        return %orig(arg1);
    }
    return %orig(arg1);
}
%end

%hook ACCCreationPublishAction
- (BOOL)is_open_hd {
    if ([BHIManager uploadHD]) {
        return 1;
    }
    return %orig;
}
- (void)setIs_open_hd:(BOOL)arg1 {
    if ([BHIManager uploadHD]) {
        %orig(1);
    }
    else {
        return %orig;
    }
}
- (BOOL)is_have_hd {
    if ([BHIManager uploadHD]) {
        return 1;
    }
    return %orig;
}
- (void)setIs_have_hd:(BOOL)arg1 {
    if ([BHIManager uploadHD]) {
        %orig(1);
    }
    else {
        return %orig;
    }
}

%end

%hook TTKCommentPanelViewController
- (void)viewDidLoad {
    %orig;
    if ([BHIManager transparentCommnet]){
        UIView *commnetView = [self view];
        [commnetView setAlpha:0.90];
    }
    if ([BHIManager disableCommentTooltips]) {
        // NOTE: placeholder — walks the view hierarchy looking for tooltip/popup
        // views by class name. This is a best-effort generic approach since the
        // exact tooltip class isn't in TikTokHeaders.h yet; verify via class-dump
        // and swap in a direct %hook on the real tooltip class for reliability.
        [self pxHideTooltipViewsIn:self.view];
    }
}
- (void)viewDidLayoutSubviews {
    %orig;
    if ([BHIManager hideEmojiPanel]) {
        [self pxHideEmojiPanelIn:self.view];
    }
    if ([BHIManager autoExpandReplies]) {
        [self pxAutoExpandRepliesIn:self.view];
    }
}
%new - (void)pxHideTooltipViewsIn:(UIView *)root {
    for (UIView *subview in root.subviews) {
        NSString *className = NSStringFromClass([subview class]);
        if ([className.lowercaseString containsString:@"tooltip"] || [className.lowercaseString containsString:@"guide"]) {
            subview.hidden = YES;
        }
        [self pxHideTooltipViewsIn:subview];
    }
}
%new - (void)pxHideEmojiPanelIn:(UIView *)root {
    // NOTE: best-effort — matches views by class name containing "emoji".
    // Verify the real class via class-dump if this doesn't catch it reliably.
    for (UIView *subview in root.subviews) {
        NSString *className = NSStringFromClass([subview class]).lowercaseString;
        if ([className containsString:@"emoji"]) {
            subview.hidden = YES;
        }
        [self pxHideEmojiPanelIn:subview];
    }
}
%new - (void)pxAutoExpandRepliesIn:(UIView *)root {
    // NOTE: best-effort — finds "View X replies" buttons by title text and taps
    // them programmatically. English-UI dependent; adjust the match string if
    // your TikTok is set to a different language.
    for (UIView *subview in root.subviews) {
        if ([subview isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)subview;
            NSString *title = [button titleForState:UIControlStateNormal].lowercaseString;
            if ([title containsString:@"repl"] && [title containsString:@"view"]) {
                [button sendActionsForControlEvents:UIControlEventTouchUpInside];
            }
        }
        [self pxAutoExpandRepliesIn:subview];
    }
}
%end

%hook AWEAwemeModel // no ads, show porgress bar
- (id)initWithDictionary:(id)arg1 error:(id *)arg2 {
    id orig = %orig;
    return [BHIManager hideAds] && self.isAds ? nil : orig;
}
- (id)init {
    id orig = %orig;
    return [BHIManager hideAds] && self.isAds ? nil : orig;
}

- (BOOL)progressBarDraggable {
    return [BHIManager progressBar] || %orig;
}
- (BOOL)progressBarVisible {
    return [BHIManager progressBar] || %orig;
}
- (void)live_callInitWithDictyCategoryMethod:(id)arg1 {
    if (![BHIManager disableLive]) {
        %orig;
    }
}
+ (id)liveStreamURLJSONTransformer {
    if ([BHIManager disableLive]) {
        return nil;
    }
    return %orig;
}
+ (id)relatedLiveJSONTransformer {
    if ([BHIManager disableLive]) {
        return nil;
    }
    return %orig;
}
+ (id)rawModelFromLiveRoomModel:(id)arg1 {
    if ([BHIManager disableLive]) {
        return nil;
    }
    return %orig;
}
+ (id)aweLiveRoom_subModelPropertyKey {
    if ([BHIManager disableLive]) {
        return nil;
    }
    return %orig;
}
%end

%hook AWEPlayInteractionWarningElementView
- (id)warningImage {
    if ([BHIManager disableWarnings]) {
        return nil;
    }
    return %orig;
}
- (id)warningLabel {
    if ([BHIManager disableWarnings]) {
        return nil;
    }
    return %orig;
}
%end

%hook TUXLabel
- (void)setText:(NSString*)arg1 {
    if ([BHIManager showUsername]) {
        if ([[[self superview] superview] isKindOfClass:%c(AWEPlayInteractionAuthorUserNameButton)]){
            AWEFeedCellViewController *rootVC = [[[self superview] superview] yy_viewController];
            AWEAwemeModel *model = rootVC.model;
            AWEUserModel *authorModel = model.author;
            NSString *nickname = authorModel.nickname;
            NSString *username = authorModel.socialName;
            %orig(username);
        }else {
            %orig;
        }
    }else {
        %orig;
    }
}
%end

%hook AWENewFeedTableViewController
- (BOOL)disablePullToRefreshGestureRecognizer {
    if ([BHIManager disablePullToRefresh]){
        return 1;
    }
    return %orig;
}

%end

%hook AWEPlayVideoPlayerController // auto play next video and stop looping video
- (void)playerWillLoopPlaying:(id)arg1 {
    if ([BHIManager autoPlay]) {
        if ([self.container.parentViewController isKindOfClass:%c(AWENewFeedTableViewController)]) {
            [((AWENewFeedTableViewController *)self.container.parentViewController) scrollToNextVideo];
            return;
        }
    }
    %orig;
}
- (BOOL)loop {
    if ([BHIManager stopPlay]) {
        return 0;
    }
    return %orig; 
}
- (void)setLoop:(BOOL)arg1 {
    if ([BHIManager stopPlay]) {
        %orig(0);
    }else {
        %orig;
    }
}
%end

%hook AWEMaskInfoModel // Disable Unsensitive Content
- (BOOL)showMask {
    if ([BHIManager disableUnsensitive]) {
        return 0;
    }
    return %orig;
}
- (void)setShowMask:(BOOL)arg1 {
    if ([BHIManager disableUnsensitive]) {
        %orig(0);
    }
    else {
        %orig;
    }
}
%end

%hook AWEAwemeACLItem // remove default watermark
- (void)setWatermarkType:(NSUInteger)arg1 {
    if ([BHIManager removeWatermark]){
        %orig(1);
    }
    else { 
        %orig;
    }
    
}
- (NSUInteger)watermarkType {
    if ([BHIManager removeWatermark]){
        return 1;
    }
    return %orig;
}
%end

static BOOL _pxFollowConfirmBypass = NO;

%hook UIButton // follow confirmation
- (void)_onTouchUpInside {
    if (!_pxFollowConfirmBypass && [BHIManager followConfirmation] && [self.currentTitle isEqualToString:@"Follow"]) {
        _pxFollowConfirmBypass = YES;
        showConfirmation(^(void) {
            [self _onTouchUpInside];
            _pxFollowConfirmBypass = NO;
        });
    } else {
        %orig;
    }
}
%end

static BOOL _pxFollowAvatarBypass = NO;

%hook AWEPlayInteractionUserAvatarElement
- (void)onFollowViewClicked:(id)sender {
    if (!_pxFollowAvatarBypass && [BHIManager followConfirmation]) {
        _pxFollowAvatarBypass = YES;
        showConfirmation(^(void) {
            [self onFollowViewClicked:sender];
            _pxFollowAvatarBypass = NO;
        });
    } else {
        %orig;
    }
}
%end

// TTKProfileBaseComponentModel — fake data removed in v1.1

static BOOL _pxLikeConfirmBypass = NO;

%hook AWEFeedVideoButton // like feed confirmation
- (void)_onTouchUpInside {
    if (!_pxLikeConfirmBypass && [BHIManager likeConfirmation] && [self.imageNameString isEqualToString:@"ic_like_fill_1_new"]) {
        _pxLikeConfirmBypass = YES;
        showConfirmation(^(void) {
            [self _onTouchUpInside];
            _pxLikeConfirmBypass = NO;
        });
    } else {
        %orig;
    }
}
%end
static BOOL _pxLikeCommentBypass = NO;
static BOOL _pxDislikeCommentBypass = NO;

%hook AWECommentPanelCell // like/dislike comment confirmation
- (void)onLikeAction:(id)arg1 {
    if (!_pxLikeCommentBypass && [BHIManager likeCommentConfirmation]) {
        _pxLikeCommentBypass = YES;
        showConfirmation(^(void) {
            [self onLikeAction:arg1];
            _pxLikeCommentBypass = NO;
        });
    } else {
        %orig;
    }
}
- (void)onDislikeAction:(id)arg1 {
    if (!_pxDislikeCommentBypass && [BHIManager dislikeCommentConfirmation]) {
        _pxDislikeCommentBypass = YES;
        showConfirmation(^(void) {
            [self onDislikeAction:arg1];
            _pxDislikeCommentBypass = NO;
        });
    } else {
        %orig;
    }
}
- (void)layoutSubviews {
    %orig;
    if (([BHIManager copyCommentWithoutUsername] || [BHIManager translateComment]) && !self.pxHasCommentGesture) {
        self.pxHasCommentGesture = YES;
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(pxHandleCommentLongPress:)];
        longPress.minimumPressDuration = 0.4;
        [self addGestureRecognizer:longPress];
    }
}
%new - (void)pxHandleCommentLongPress:(UILongPressGestureRecognizer *)sender {
    if (sender.state != UIGestureRecognizerStateBegan) return;

    // NOTE: "commentModel"/"text" are placeholders — confirm the real key path via
    // Real property names confirmed via class-dump of MusicallyCore binary v46.0.0:
    // commentText = plain text body; commentContent = richer variant (same content, different type).
    id commentModel = [self valueForKey:@"commentModel"];
    NSString *commentText = [commentModel valueForKey:@"commentText"];
    if (commentText.length == 0) {
        commentText = [commentModel valueForKey:@"commentContent"];
    }
    if (commentText.length == 0) return;

    TUXActionSheetController *alert = [[%c(TUXActionSheetController) alloc] initWithTitle:@""];
    if ([BHIManager copyCommentWithoutUsername]) {
        [alert addAction:[[%c(TUXActionSheetAction) alloc] initWithStyle:0 title:@"Copy comment text" subtitle:nil image:[UIImage systemImageNamed:@"clipboard"] imageLabel:nil handler:^(TUXActionSheetAction * _Nonnull action) {
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            pasteboard.string = commentText;
            PXScheduleClipboardClear();
        }]];
    }
    if ([BHIManager translateComment]) {
        [alert addAction:[[%c(TUXActionSheetAction) alloc] initWithStyle:0 title:@"Translate comment" subtitle:nil image:[UIImage systemImageNamed:@"globe"] imageLabel:nil handler:^(TUXActionSheetAction * _Nonnull action) {
            PXTranslateText(commentText);
        }]];
    }
    [alert setDismissOnDraggingDown:true];
    [self.yy_viewController presentViewController:alert animated:YES completion:nil];
}
%property (nonatomic, assign) BOOL pxHasCommentGesture;
%end

%hook AWEUserModel // follower, following Count fake  
- (NSNumber *)followerCount {
    if ([BHIManager fakeChangesEnabled]) {
        NSString *fakeCountString = [[NSUserDefaults standardUserDefaults] stringForKey:@"follower_count"];
        if (!(fakeCountString.length == 0)) {
            NSInteger fakeCount = [fakeCountString integerValue];
            return [NSNumber numberWithInt:fakeCount];
        }

        return %orig;
    }

    return %orig;
}
- (NSNumber *)followingCount {
    if ([BHIManager fakeChangesEnabled]) {
        NSString *fakeCountString = [[NSUserDefaults standardUserDefaults] stringForKey:@"following_count"];
        if (!(fakeCountString.length == 0)) {
            NSInteger fakeCount = [fakeCountString integerValue];
            return [NSNumber numberWithInt:fakeCount];
        }

        return %orig;
    }

    return %orig;
}
%end

%hook AWETextInputController
- (NSUInteger)maxLength {
    if ([BHIManager extendedComment]) {
        return 500;
    }

    return %orig;
}
%end
%hook AWEPlayVideoPlayerController
- (void)containerDidFullyDisplayWithReason:(NSInteger)arg1 {
    if ([[[self container] parentViewController] isKindOfClass:%c(AWENewFeedTableViewController)] && [BHIManager skipRecommendations]) {
        AWENewFeedTableViewController *rootVC = [[self container] parentViewController];
        AWEAwemeModel *currentModel = [rootVC currentAweme];
        if ([currentModel isUserRecommendBigCard]) {
            [rootVC scrollToNextVideo];
        }
    }else {
        %orig;
    }

    // Usage stats: count this as a watched video (once per fully-displayed container).
    NSInteger totalVideos = [[NSUserDefaults standardUserDefaults] integerForKey:@"px_total_videos"];
    [[NSUserDefaults standardUserDefaults] setInteger:totalVideos + 1 forKey:@"px_total_videos"];

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    NSString *todayKey = [formatter stringFromDate:[NSDate date]];
    NSString *storedDay = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_stats_day"];
    NSInteger todayVideos = [[NSUserDefaults standardUserDefaults] integerForKey:@"px_today_videos"];
    if (![storedDay isEqualToString:todayKey]) {
        todayVideos = 0;
        [[NSUserDefaults standardUserDefaults] setDouble:0 forKey:@"px_today_seconds"];
        [[NSUserDefaults standardUserDefaults] setValue:todayKey forKey:@"px_stats_day"];
    }
    [[NSUserDefaults standardUserDefaults] setInteger:todayVideos + 1 forKey:@"px_today_videos"];
}
%end
%hook AWEProfileEditTextViewController
- (NSInteger)maxTextLength {
    if ([BHIManager extendedBio]) {
        return 222;
    }

    return %orig;
}
%end
%hook AWEPlayInteractionAuthorView
%new - (NSString *)emojiForCountryCode:(NSString *)countryCode {
    // Convert the country code to uppercase
    NSString *uppercaseCountryCode = [countryCode uppercaseString];
    
    // Ensure the country code has exactly two characters
    if (uppercaseCountryCode.length != 2) {
        return nil;
    }
    
    // Convert the country code to the regional indicator symbols
    uint32_t firstLetter = [uppercaseCountryCode characterAtIndex:0] + 0x1F1E6 - 'A';
    uint32_t secondLetter = [uppercaseCountryCode characterAtIndex:1] + 0x1F1E6 - 'A';
    
    // Create the emoji using the regional indicator symbols
    NSString *flagEmoji = [[NSString alloc] initWithBytes:&firstLetter length:4 encoding:NSUTF32LittleEndianStringEncoding];
    flagEmoji = [flagEmoji stringByAppendingString:[[NSString alloc] initWithBytes:&secondLetter length:4 encoding:NSUTF32LittleEndianStringEncoding]];
    
    return flagEmoji;
}

- (void)layoutSubviews {
    %orig;
    if ([BHIManager uploadRegion]){
        for (int i = 0; i < [[self subviews] count]; i ++){
            id j = [[self subviews] objectAtIndex:i];
            if ([j isKindOfClass:%c(UIStackView)]){
                CGRect frame = [j frame];
                frame.origin.x = 39.5; 
                [j setFrame:frame];
            }else {
                [[self viewWithTag:666] removeFromSuperview];
            }
        }
        [[self viewWithTag:666] removeFromSuperview];
        AWEFeedCellViewController* rootVC = self.yy_viewController;
        AWEAwemeModel *model = rootVC.model;
        NSString *countryID = model.region;
        UILabel *uploadLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,2,39.5,20.5)];
        NSString *countryEmoji = [self emojiForCountryCode:countryID];
        uploadLabel.text = [NSString stringWithFormat:@"%@ •",countryEmoji];
        uploadLabel.tag = 666;
        [uploadLabel setTextColor: [UIColor whiteColor]];
        [uploadLabel sizeToFit];
        [self addSubview:uploadLabel];
    }
}
%end
%hook TIKTOKProfileHeaderView // copy profile information
- (id)initWithFrame:(CGRect)arg1 {
    self = %orig;
    if ([BHIManager profileCopy]) {
        [self addHandleLongPress];
    }
    return self;
}
%end

%hook AWELiveFeedEntranceView
- (void)switchStateWithTapped:(BOOL)arg1 {
    if (![BHIManager liveActionEnabled] || [BHIManager selectedLiveAction] == 0) {
        %orig;
    } else if ([BHIManager liveActionEnabled] && [[BHIManager selectedLiveAction] intValue] == 1) {
        PXMenuTabBarController *menu = [[PXMenuTabBarController alloc] init];
        menu.modalPresentationStyle = UIModalPresentationFormSheet;
        [topMostController() presentViewController:menu animated:YES completion:nil];
    } 
    else {
        %orig;
    }

}
- (void)layoutSubviews {
    %orig;
    if ([BHIManager hideLiveBadge]) {
        self.hidden = YES;
    }
}
%end


%hook AWEFeedViewTemplateCell
%property (nonatomic, strong) JGProgressHUD *hud;
%property(nonatomic, assign) BOOL elementsHidden;
%property (nonatomic, retain) NSString *fileextension;
%property (nonatomic, retain) UIProgressView *progressView;
- (void)configWithModel:(id)model {
    %orig;
    self.elementsHidden = false;
    if ([BHIManager downloadButton]){
        [self addDownloadButton];
    }
    if ([BHIManager hideElementButton]) {
        [self addHideElementButton];
    }
}
- (void)configureWithModel:(id)model {
    %orig;
    self.elementsHidden = false;
    if ([BHIManager downloadButton]){
        [self addDownloadButton];
    }
    if ([BHIManager hideElementButton]) {
        [self addHideElementButton];
    }
}
%new - (void)addDownloadButton {
    UIButton *downloadButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [downloadButton setTag:998];
    [downloadButton setTranslatesAutoresizingMaskIntoConstraints:false];
    [downloadButton addTarget:self action:@selector(downloadButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
    [downloadButton setImage:[UIImage systemImageNamed:@"arrow.down"] forState:UIControlStateNormal];
    if (![self viewWithTag:998]) {
        [downloadButton setTintColor:[UIColor whiteColor]];
        [self addSubview:downloadButton];

        [NSLayoutConstraint activateConstraints:@[
            [downloadButton.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:90],
            [downloadButton.trailingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.trailingAnchor constant:-10],
            [downloadButton.widthAnchor constraintEqualToConstant:30],
            [downloadButton.heightAnchor constraintEqualToConstant:30],
        ]];
    }
}
%new - (void)downloadHDVideo:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [NSURL URLWithString:[NSString stringWithFormat:@"https://tikwm.com/video/media/hdplay/%@.mp4", as]];
    self.fileextension = [rootVC.model.video.playURL bestURLtoDownloadFormat];
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)downloadVideo:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
    self.fileextension = [rootVC.model.video.playURL bestURLtoDownloadFormat];
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)downloadPhotos:(TTKPhotoAlbumDetailCellController *)rootVC photoIndex:(unsigned long)index {
    AWEPlayPhotoAlbumViewController *photoAlbumController = [rootVC valueForKey:@"_photoAlbumController"];
            NSArray <AWEPhotoAlbumPhoto *> *photos = rootVC.model.photoAlbum.photos;
            AWEPhotoAlbumPhoto *currentPhoto = [photos objectAtIndex:index];

                NSURL *downloadableURL = [currentPhoto.originPhotoURL bestURLtoDownload];
                self.fileextension = [currentPhoto.originPhotoURL bestURLtoDownloadFormat];
                if (downloadableURL) {
                    BHDownload *dwManager = [[BHDownload alloc] init];
                    [dwManager downloadFileWithURL:downloadableURL];
                    [dwManager setDelegate:self];
                    self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
                    self.hud.textLabel.text = @"Downloading";
                     [self.hud showInView:topMostController().view];
                }
            
    }

%new - (void)downloadPhotos:(TTKPhotoAlbumDetailCellController *)rootVC {
    NSString *video_description = rootVC.model.music_songName;
    AWEPlayPhotoAlbumViewController *photoAlbumController = [rootVC valueForKey:@"_photoAlbumController"];

            NSArray <AWEPhotoAlbumPhoto *> *photos = rootVC.model.photoAlbum.photos;
            NSMutableArray<NSURL *> *fileURLs = [NSMutableArray array];

            for (AWEPhotoAlbumPhoto *currentPhoto in photos) {
                NSURL *downloadableURL = [currentPhoto.originPhotoURL bestURLtoDownload];
                self.fileextension = [currentPhoto.originPhotoURL bestURLtoDownloadFormat];
                if (downloadableURL) {
                    [fileURLs addObject:downloadableURL];
                }
            }

            BHMultipleDownload *dwManager = [[BHMultipleDownload alloc] init];
            [dwManager setDelegate:self];
            [dwManager downloadFiles:fileURLs];
            self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
            self.hud.textLabel.text = @"Downloading";
            [self.hud showInView:topMostController().view];

}
%new - (void)downloadMusic:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
    self.fileextension = @"mp3";
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)copyMusic:(AWEAwemeBaseViewController *)rootVC {
    NSURL *downloadableURL = [((AWEMusicModel *)rootVC.model.music).playURL bestURLtoDownload];
    if (downloadableURL) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = [downloadableURL absoluteString];
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"Не удалось скопировать музыку" : @"Could Not Copy Music.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)copyVideo:(AWEAwemeBaseViewController *)rootVC {
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
    if (downloadableURL) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = [downloadableURL absoluteString];
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"В видео нет музыки для скачивания" : @"This video has no music to download.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)copyDecription:(AWEAwemeBaseViewController *)rootVC {
    NSString *video_description = rootVC.model.music_songName;
    if (video_description) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = video_description;
        PXScheduleClipboardClear();
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"В видео нет музыки для скачивания" : @"This video has no music to download.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)translateDecription:(AWEAwemeBaseViewController *)rootVC {
    NSString *video_description = rootVC.model.music_songName;
    PXTranslateText(video_description);
}
%new - (void) downloadButtonHandler:(UIButton *)sender {
    AWEAwemeBaseViewController *rootVC = self.viewController;
    if ([rootVC isKindOfClass:%c(AWEFeedCellViewController)]) {

         UIAction *action1 = [UIAction actionWithTitle:@"Download Video"
                                            image:[UIImage systemImageNamed:@"film"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadVideo:rootVC];
    }];
        UIAction *action0 = [UIAction actionWithTitle:@"Download HD Video"
                                            image:[UIImage systemImageNamed:@"film"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadHDVideo:rootVC];
    }];
    UIAction *action2 = [UIAction actionWithTitle:@"Download Music"
                                            image:[UIImage systemImageNamed:@"music.note"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadMusic:rootVC];
    }];
    UIAction *action3 = [UIAction actionWithTitle:@"Copy Music link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyMusic:rootVC];
    }];
    UIAction *action4 = [UIAction actionWithTitle:@"Copy Video link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyVideo:rootVC];
    }];
    UIAction *action5 = [UIAction actionWithTitle:@"Copy Decription"
                                            image:[UIImage systemImageNamed:@"note.text"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyDecription:rootVC];
    }];
    UIAction *action6 = [UIAction actionWithTitle:@"Translate Description"
                                            image:[UIImage systemImageNamed:@"globe"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self translateDecription:rootVC];
    }];
    UIMenu *downloadMenu = [UIMenu menuWithTitle:@"Downloads Menu"
                                        children:@[action1, action0,action2]];
    UIMenu *copyMenu = [UIMenu menuWithTitle:@"Copy Menu"
                                        children:[BHIManager translateDescription] ? @[action3, action4, action5, action6] : @[action3, action4, action5]];
    UIMenu *mainMenu = [UIMenu menuWithTitle:@"" children:@[downloadMenu, copyMenu]];
    [sender setMenu:mainMenu];
    sender.showsMenuAsPrimaryAction = YES;
    } else if ([self.viewController isKindOfClass:%c(TTKPhotoAlbumDetailCellController)]) {
        TTKPhotoAlbumDetailCellController *rootVC = self.viewController;
        AWEPlayPhotoAlbumViewController *photoAlbumController = [rootVC valueForKey:@"_photoAlbumController"];
        NSArray <AWEPhotoAlbumPhoto *> *photos = rootVC.model.photoAlbum.photos;
        unsigned long photosCount = [photos count];
        NSMutableArray <UIAction *> *photosActions = [NSMutableArray array];
            for (int i = 0; i < photosCount; i++) {
        NSString *title = [NSString stringWithFormat:@"Download Photo %d", i+1];
        UIAction *action = [UIAction actionWithTitle:title
                                               image:[UIImage systemImageNamed:@"photo.fill"]
                                          identifier:nil
                                             handler:^(__kindof UIAction * _Nonnull action) {
                                                [self downloadPhotos:rootVC photoIndex:i];
        }];
        [photosActions addObject:action];

    }
    UIAction *allPhotosAction = [UIAction actionWithTitle:@"Download All Photos"
                                            image:[UIImage systemImageNamed:@"photo.fill"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadPhotos:rootVC];
    }];
    [photosActions addObject:allPhotosAction];
    UIAction *action2 = [UIAction actionWithTitle:@"Download Music"
                                            image:[UIImage systemImageNamed:@"music.note"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadMusic:rootVC];
    }];
    UIAction *action3 = [UIAction actionWithTitle:@"Copy Music link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyMusic:rootVC];
    }];
    UIAction *action4 = [UIAction actionWithTitle:@"Copy Video link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyVideo:rootVC];
    }];
    UIAction *action5 = [UIAction actionWithTitle:@"Copy Decription"
                                            image:[UIImage systemImageNamed:@"note.text"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyDecription:rootVC];
    }];
    UIAction *action6 = [UIAction actionWithTitle:@"Translate Description"
                                            image:[UIImage systemImageNamed:@"globe"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self translateDecription:rootVC];
    }];
    UIMenu *PhotosMenu = [UIMenu menuWithTitle:@"Download Photos Menu"
                                        children:photosActions];
    UIMenu *downloadMenu = [UIMenu menuWithTitle:@"Downloads Menu"
                                        children:@[action2]];
    UIMenu *copyMenu = [UIMenu menuWithTitle:@"Copy Menu"
                                        children:[BHIManager translateDescription] ? @[action3, action4, action5, action6] : @[action3, action4, action5]];
    UIMenu *mainMenu = [UIMenu menuWithTitle:@"" children:@[PhotosMenu, downloadMenu, copyMenu]];
    [sender setMenu:mainMenu];
    sender.showsMenuAsPrimaryAction = YES;
    }else if ([self.viewController isKindOfClass:%c(TTKPhotoAlbumFeedCellController)]) {
        TTKPhotoAlbumFeedCellController *rootVC = self.viewController;
        AWEPlayPhotoAlbumViewController *photoAlbumController = [rootVC valueForKey:@"_photoAlbumController"];
        NSArray <AWEPhotoAlbumPhoto *> *photos = rootVC.model.photoAlbum.photos;
        unsigned long photosCount = [photos count];
        NSMutableArray <UIAction *> *photosActions = [NSMutableArray array];
            for (int i = 0; i < photosCount; i++) {
        NSString *title = [NSString stringWithFormat:@"Download Photo %d", i+1];
        UIAction *action = [UIAction actionWithTitle:title
                                               image:[UIImage systemImageNamed:@"photo.fill"]
                                          identifier:nil
                                             handler:^(__kindof UIAction * _Nonnull action) {
                                                [self downloadPhotos:rootVC photoIndex:i];
        }];
        [photosActions addObject:action];

    }
        UIAction *allPhotosAction = [UIAction actionWithTitle:@"Download Photos"
                                            image:[UIImage systemImageNamed:@"photo.fill"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadPhotos:rootVC];
    }];
    [photosActions addObject:allPhotosAction];
    UIAction *action2 = [UIAction actionWithTitle:@"Download Music"
                                            image:[UIImage systemImageNamed:@"music.note"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadMusic:rootVC];
    }];
    UIAction *action3 = [UIAction actionWithTitle:@"Copy Music link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyMusic:rootVC];
    }];
    UIAction *action4 = [UIAction actionWithTitle:@"Copy Video link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyVideo:rootVC];
    }];
    UIAction *action5 = [UIAction actionWithTitle:@"Copy Decription"
                                            image:[UIImage systemImageNamed:@"note.text"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyDecription:rootVC];
    }];
    UIAction *action6 = [UIAction actionWithTitle:@"Translate Description"
                                            image:[UIImage systemImageNamed:@"globe"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self translateDecription:rootVC];
    }];
    UIMenu *PhotosMenu = [UIMenu menuWithTitle:@"Download Photos Menu"
                                        children:photosActions];
    UIMenu *downloadMenu = [UIMenu menuWithTitle:@"Downloads Menu"
                                        children:@[action2]];
    UIMenu *copyMenu = [UIMenu menuWithTitle:@"Copy Menu"
                                        children:[BHIManager translateDescription] ? @[action3, action4, action5, action6] : @[action3, action4, action5]];
    UIMenu *mainMenu = [UIMenu menuWithTitle:@"" children:@[PhotosMenu, downloadMenu, copyMenu]];
    [sender setMenu:mainMenu];
    sender.showsMenuAsPrimaryAction = YES;
    }
}
%new - (void)addHideElementButton {
    UIButton *hideElementButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [hideElementButton setTag:999];
    [hideElementButton setTranslatesAutoresizingMaskIntoConstraints:false];
    [hideElementButton addTarget:self action:@selector(hideElementButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
    if (self.elementsHidden) {
        [hideElementButton setImage:[UIImage systemImageNamed:@"eye"] forState:UIControlStateNormal];
    } else {
        [hideElementButton setImage:[UIImage systemImageNamed:@"eye.slash"] forState:UIControlStateNormal];
    }

    if (![self viewWithTag:999]) {
        [hideElementButton setTintColor:[UIColor whiteColor]];
        [self addSubview:hideElementButton];

        [NSLayoutConstraint activateConstraints:@[
            [hideElementButton.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:50],
            [hideElementButton.trailingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.trailingAnchor constant:-10],
            [hideElementButton.widthAnchor constraintEqualToConstant:30],
            [hideElementButton.heightAnchor constraintEqualToConstant:30],
        ]];
    }
}
%new - (void)hideElementButtonHandler:(UIButton *)sender {
    AWEAwemeBaseViewController *rootVC = self.viewController;
    if ([rootVC.interactionController isKindOfClass:%c(TTKFeedInteractionLegacyMainContainerElement)]) {
        TTKFeedInteractionLegacyMainContainerElement *interactionController = rootVC.interactionController;
        if (self.elementsHidden) {
            self.elementsHidden = false;
            [interactionController hideAllElements:false exceptArray:nil];
            [sender setImage:[UIImage systemImageNamed:@"eye.slash"] forState:UIControlStateNormal];
        } else {
            self.elementsHidden = true;
            [interactionController hideAllElements:true exceptArray:nil];
            [sender setImage:[UIImage systemImageNamed:@"eye"] forState:UIControlStateNormal];
        }
    }
}

%new - (void)downloaderProgress:(float)progress {
    self.hud.detailTextLabel.text = [BHIManager getDownloadingPersent:progress];
}
%new - (void)downloaderDidFinishDownloadingAllFiles:(NSMutableArray<NSURL *> *)downloadedFilePaths {
    [self.hud dismiss];
    if ([BHIManager shareSheet]) {
        [BHIManager showSaveVC:downloadedFilePaths];
    }
    else {
        for (NSURL *url in downloadedFilePaths) {
            [BHIManager saveMedia:url fileExtension:self.fileextension];
        }
    }
}
%new - (void)downloaderDidFailureWithError:(NSError *)error {
    if (error) {
        [self.hud dismiss];
    }
}

%new - (void)downloadProgress:(float)progress {
    self.progressView.progress = progress;
    self.hud.detailTextLabel.text = [BHIManager getDownloadingPersent:progress];
    self.hud.tapOutsideBlock = ^(JGProgressHUD * _Nonnull HUD) {
        self.hud.textLabel.text = @"Backgrounding ✌️";
        [self.hud dismissAfterDelay:0.4];
    };
}
%new - (void)downloadDidFinish:(NSURL *)filePath Filename:(NSString *)fileName {
    NSString *DocPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true).firstObject;
    NSFileManager *manager = [NSFileManager defaultManager];
    NSURL *newFilePath = [[NSURL fileURLWithPath:DocPath] URLByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", NSUUID.UUID.UUIDString, self.fileextension]];
    [manager moveItemAtURL:filePath toURL:newFilePath error:nil];
    [self.hud dismiss];
    NSArray *audioExtensions = @[@"mp3", @"aac", @"wav", @"m4a", @"ogg", @"flac", @"aiff", @"wma"];
    if ([BHIManager shareSheet] || [audioExtensions containsObject:self.fileextension]) {
        [BHIManager showSaveVC:@[newFilePath]];
    }
    else {
        [BHIManager saveMedia:newFilePath fileExtension:self.fileextension];
    }
}
%new - (void)downloadDidFailureWithError:(NSError *)error {
    if (error) {
        [self.hud dismiss];
    }
}
%end

%hook AWEAwemeDetailTableViewCell
%property (nonatomic, strong) JGProgressHUD *hud;
%property(nonatomic, assign) BOOL elementsHidden;
%property (nonatomic, retain) UIProgressView *progressView;
%property (nonatomic, retain) NSString *fileextension;
- (void)configWithModel:(id)model {
    %orig;
    self.elementsHidden = false;
    if ([BHIManager downloadButton]){
        [self addDownloadButton];
    }
    if ([BHIManager hideElementButton]) {
        [self addHideElementButton];
    }
}
- (void)configureWithModel:(id)model {
    %orig;
    self.elementsHidden = false;
    if ([BHIManager downloadButton]){
        [self addDownloadButton];
    }
    if ([BHIManager hideElementButton]) {
        [self addHideElementButton];
    }
}
%new - (void)addDownloadButton {
    UIButton *downloadButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [downloadButton setTag:998];
    [downloadButton setTranslatesAutoresizingMaskIntoConstraints:false];
    [downloadButton addTarget:self action:@selector(downloadButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
    [downloadButton setImage:[UIImage systemImageNamed:@"arrow.down"] forState:UIControlStateNormal];
    if (![self viewWithTag:998]) {
        [downloadButton setTintColor:[UIColor whiteColor]];
        [self addSubview:downloadButton];

        [NSLayoutConstraint activateConstraints:@[
            [downloadButton.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:90],
            [downloadButton.trailingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.trailingAnchor constant:-10],
            [downloadButton.widthAnchor constraintEqualToConstant:30],
            [downloadButton.heightAnchor constraintEqualToConstant:30],
        ]];
    }
}
%new - (void)downloadHDVideo:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [NSURL URLWithString:[NSString stringWithFormat:@"https://tikwm.com/video/media/hdplay/%@.mp4", as]];
    self.fileextension = [rootVC.model.video.playURL bestURLtoDownloadFormat];
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)downloadVideo:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
        self.fileextension = [rootVC.model.video.playURL bestURLtoDownloadFormat];
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)downloadMusic:(AWEAwemeBaseViewController *)rootVC {
    NSString *as = rootVC.model.itemID;
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
        self.fileextension = @"mp3";
    if (downloadableURL) {
        BHDownload *dwManager = [[BHDownload alloc] init];
        [dwManager downloadFileWithURL:downloadableURL];
        [dwManager setDelegate:self];
        self.hud = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
        self.hud.textLabel.text = @"Downloading";
        [self.hud showInView:topMostController().view];
    }
}
%new - (void)copyMusic:(AWEAwemeBaseViewController *)rootVC {
    NSURL *downloadableURL = [((AWEMusicModel *)rootVC.model.music).playURL bestURLtoDownload];
    if (downloadableURL) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = [downloadableURL absoluteString];
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"В видео нет музыки для скачивания" : @"This video has no music to download.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)copyVideo:(AWEAwemeBaseViewController *)rootVC {
    NSURL *downloadableURL = [rootVC.model.video.playURL bestURLtoDownload];
    if (downloadableURL) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = [downloadableURL absoluteString];
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"В видео нет музыки для скачивания" : @"This video has no music to download.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)copyDecription:(AWEAwemeBaseViewController *)rootVC {
    NSString *video_description = rootVC.model.music_songName;
    if (video_description) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = video_description;
        PXScheduleClipboardClear();
    } else {
        [%c(AWEUIAlertView) showAlertWithTitle:@"PXTok" description:([BHIManager isRussian] ? @"В видео нет музыки для скачивания" : @"This video has no music to download.") image:nil actionButtonTitle:@"OK" cancelButtonTitle:nil actionBlock:nil cancelBlock:nil];
    }
}
%new - (void)translateDecription:(AWEAwemeBaseViewController *)rootVC {
    NSString *video_description = rootVC.model.music_songName;
    PXTranslateText(video_description);
}
%new - (void) downloadButtonHandler:(UIButton *)sender {
    AWEAwemeBaseViewController *rootVC = self.viewController;
    if ([rootVC.interactionController isKindOfClass:%c(TTKFeedInteractionLegacyMainContainerElement)]) {

     UIAction *action1 = [UIAction actionWithTitle:@"Download Video"
                                            image:[UIImage systemImageNamed:@"film"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadVideo:rootVC];
    }];
    UIAction *action0 = [UIAction actionWithTitle:@"Download HD Video"
                                            image:[UIImage systemImageNamed:@"film"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadHDVideo:rootVC];
    }];
    UIAction *action2 = [UIAction actionWithTitle:@"Download Music"
                                            image:[UIImage systemImageNamed:@"music.note"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self downloadMusic:rootVC];
    }];
    UIAction *action3 = [UIAction actionWithTitle:@"Copy Music link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyMusic:rootVC];
    }];
    UIAction *action4 = [UIAction actionWithTitle:@"Copy Video link"
                                            image:[UIImage systemImageNamed:@"link"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyVideo:rootVC];
    }];
    UIAction *action5 = [UIAction actionWithTitle:@"Copy Decription"
                                            image:[UIImage systemImageNamed:@"note.text"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self copyDecription:rootVC];
    }];
    UIAction *action6 = [UIAction actionWithTitle:@"Translate Description"
                                            image:[UIImage systemImageNamed:@"globe"]
                                       identifier:nil
                                          handler:^(__kindof UIAction * _Nonnull action) {
                                            [self translateDecription:rootVC];
    }];
    UIMenu *downloadMenu = [UIMenu menuWithTitle:@"Downloads Menu"
                                        children:@[action1, action0,action2]];
    UIMenu *copyMenu = [UIMenu menuWithTitle:@"Copy Menu"
                                        children:[BHIManager translateDescription] ? @[action3, action4, action5, action6] : @[action3, action4, action5]];
    UIMenu *mainMenu = [UIMenu menuWithTitle:@"" children:@[downloadMenu, copyMenu]];
    [sender setMenu:mainMenu];
    sender.showsMenuAsPrimaryAction = YES;
    }
}
%new - (void)addHideElementButton {
    UIButton *hideElementButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [hideElementButton setTag:999];
    [hideElementButton setTranslatesAutoresizingMaskIntoConstraints:false];
    [hideElementButton addTarget:self action:@selector(hideElementButtonHandler:) forControlEvents:UIControlEventTouchUpInside];
    if (self.elementsHidden) {
        [hideElementButton setImage:[UIImage systemImageNamed:@"eye"] forState:UIControlStateNormal];
    } else {
        [hideElementButton setImage:[UIImage systemImageNamed:@"eye.slash"] forState:UIControlStateNormal];
    }

    if (![self viewWithTag:999]) {
        [hideElementButton setTintColor:[UIColor whiteColor]];
        [self addSubview:hideElementButton];

        [NSLayoutConstraint activateConstraints:@[
            [hideElementButton.topAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.topAnchor constant:50],
            [hideElementButton.trailingAnchor constraintEqualToAnchor:self.safeAreaLayoutGuide.trailingAnchor constant:-10],
            [hideElementButton.widthAnchor constraintEqualToConstant:30],
            [hideElementButton.heightAnchor constraintEqualToConstant:30],
        ]];
    }
}
%new - (void)hideElementButtonHandler:(UIButton *)sender {
    AWEAwemeBaseViewController *rootVC = self.viewController;
    if ([rootVC.interactionController isKindOfClass:%c(TTKFeedInteractionLegacyMainContainerElement)]) {
        TTKFeedInteractionLegacyMainContainerElement *interactionController = rootVC.interactionController;
        if (self.elementsHidden) {
            self.elementsHidden = false;
            [interactionController hideAllElements:false exceptArray:nil];
            [sender setImage:[UIImage systemImageNamed:@"eye.slash"] forState:UIControlStateNormal];
        } else {
            self.elementsHidden = true;
            [interactionController hideAllElements:true exceptArray:nil];
            [sender setImage:[UIImage systemImageNamed:@"eye"] forState:UIControlStateNormal];
        }
    }
}

%new - (void)downloadProgress:(float)progress {
        self.hud.tapOutsideBlock = ^(JGProgressHUD * _Nonnull HUD) {
        self.hud.textLabel.text = @"Backgrounding ✌️";
        [self.hud dismissAfterDelay:0.4];
    };
    self.progressView.progress = progress;
    self.hud.detailTextLabel.text = [BHIManager getDownloadingPersent:progress];
}
%new - (void)downloadDidFinish:(NSURL *)filePath Filename:(NSString *)fileName {
    NSString *DocPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true).firstObject;
    NSFileManager *manager = [NSFileManager defaultManager];
    NSURL *newFilePath = [[NSURL fileURLWithPath:DocPath] URLByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", NSUUID.UUID.UUIDString, self.fileextension]];
    [manager moveItemAtURL:filePath toURL:newFilePath error:nil];
    [self.hud dismiss];
    NSArray *audioExtensions = @[@"mp3", @"aac", @"wav", @"m4a", @"ogg", @"flac", @"aiff", @"wma"];
    if ([BHIManager shareSheet] || [audioExtensions containsObject:self.fileextension]) {
        [BHIManager showSaveVC:@[newFilePath]];
    }
    else {
        [BHIManager saveMedia:newFilePath fileExtension:self.fileextension];
    }
}
%new - (void)downloadDidFailureWithError:(NSError *)error {
    if (error) {
        [self.hud dismiss];
    }
}
%end

%hook TTKStoryDetailTableViewCell
    // TODO...
%end

%hook AWEURLModel
%new - (NSString *)bestURLtoDownloadFormat {
    NSURL *bestURLFormat;
    for (NSString *url in self.originURLList) {
        if ([url containsString:@"video_mp4"]) {
            bestURLFormat = @"mp4";
        } else if ([url containsString:@".jpeg"]) {
            bestURLFormat = @"jpeg";
        } else if ([url containsString:@".png"]) {
            bestURLFormat = @"png";
        } else if ([url containsString:@".mp3"]) {
            bestURLFormat = @"mp3";
        } else if ([url containsString:@".m4a"]) {
            bestURLFormat = @"m4a";
        }
    }
    if (bestURLFormat == nil) {
        bestURLFormat = @"m4a";
    }

    return bestURLFormat;
}
%new - (NSURL *)bestURLtoDownload {
    NSURL *bestURL;
    for (NSString *url in self.originURLList) {
        if ([url containsString:@"video_mp4"] || [url containsString:@".jpeg"] || [url containsString:@".mp3"]) {
            bestURL = [NSURL URLWithString:url];
        }
    }

    if (bestURL == nil) {
        bestURL = [NSURL URLWithString:[self.originURLList firstObject]];
    }

    return bestURL;
}
%end

%hook NSFileManager
-(BOOL)fileExistsAtPath:(id)arg1 {
        for (NSString *file in jailbreakPaths) {
                if ([arg1 isEqualToString:file]) {
                        return NO;
                }
        }
        return %orig;
}
-(BOOL)fileExistsAtPath:(id)arg1 isDirectory:(BOOL*)arg2 {
        for (NSString *file in jailbreakPaths) {
                if ([arg1 isEqualToString:file]) {
                        return NO;
                }
        }
        return %orig;
}
%end
%hook BDADeviceHelper
+(bool)isJailBroken {
        return NO;
}
%end

%hook UIDevice
+(bool)btd_isJailBroken {
        return NO;
}
%end

%hook TTInstallUtil
+(bool)isJailBroken {
        return NO;
}
%end

%hook AppsFlyerUtils
+(bool)isJailbrokenWithSkipAdvancedJailbreakValidation:(bool)arg2 {
        return NO;
}
%end

%hook PIPOIAPStoreManager
-(bool)_pipo_isJailBrokenDeviceWithProductID:(id)arg2 orderID:(id)arg3 {
        return NO;
}
%end

%hook IESLiveDeviceInfo
+(bool)isJailBroken {
        return NO;
}
%end

%hook PIPOStoreKitHelper
-(bool)isJailBroken {
        return NO;
}
%end

%hook BDInstallNetworkUtility
+(bool)isJailBroken {
        return NO;
}
%end

%hook TTAdSplashDeviceHelper
+(bool)isJailBroken {
        return NO;
}
%end

%hook GULAppEnvironmentUtil
+(bool)isFromAppStore {
        return YES;
}
+(bool)isAppStoreReceiptSandbox {
        return NO;
}
+(bool)isAppExtension {
        return YES;
}
%end

%hook FBSDKAppEventsUtility
+(bool)isDebugBuild {
        return NO;
}
%end

%hook AWEAPMManager
+(id)signInfo {
        return @"AppStore";
}
%end

%hook NSBundle
-(id)pathForResource:(id)arg1 ofType:(id)arg2 {
        if ([arg2 isEqualToString:@"mobileprovision"]) {
                return nil;
        }
        return %orig;
}
%end
%hook AWESecurity
- (void)resetCollectMode {
        return;
}
%end
%hook MSManagerOV
- (id)setMode {
        return (id (^)(id)) ^{
        };
}
%end
%hook MSConfigOV
- (id)setMode {
        return (id (^)(id)) ^{
        };
}
%end


// ═══════════════════════════════════════════════════════════════
// GHOST: скрытие онлайн-статуса
// ═══════════════════════════════════════════════════════════════
%hook TIMConversationOnlineStatusImpl
- (void)reportUserOnlineStatus:(id)status completion:(id)completion {
    if ([BHIManager ghostHideOnline]) return;
    %orig;
}
%end

%hook AWEIMTypingManager
- (void)startTypingInConversation:(id)conv {
    if ([BHIManager ghostHideTyping]) return;
    %orig;
}
- (void)stopTypingInConversation:(id)conv {
    if ([BHIManager ghostHideTyping]) return;
    %orig;
}
%end

// ═══════════════════════════════════════════════════════════════
// GHOST: скрытие просмотра историй и видео
// ═══════════════════════════════════════════════════════════════
%hook AWEStoryInteractionController
- (void)reportStoryView:(id)arg1 {
    if ([BHIManager ghostNoStoryMark]) return;
    %orig;
}
%end

%hook AWEFeedVideoPlayStatisticsManager
- (void)reportVideoPlayWithModel:(id)model {
    if ([BHIManager ghostNoVideoMark]) return;
    %orig;
}
%end

// ═══════════════════════════════════════════════════════════════
// GHOST: скрытый просмотр профиля
// ═══════════════════════════════════════════════════════════════
%hook AWEUserDetailInteractiveManager
- (void)reportProfileView:(id)profile {
    if ([BHIManager ghostStealthProfile]) return;
    %orig;
}
%end

// ═══════════════════════════════════════════════════════════════
// УДАЛЁННЫЕ СООБЩЕНИЯ — кэшируем перед удалением
// ═══════════════════════════════════════════════════════════════

// Хук на входящие сообщения — сохраняем копию до того как TikTok удалит
%hook TIMMessageManager
- (void)onRecvMessages:(NSArray *)messages {
    %orig;
    if (![BHIManager deletedMessagesEnabled]) return;
    // Кэшируем входящие сообщения
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        NSMutableDictionary *cache = [[[NSUserDefaults standardUserDefaults] dictionaryForKey:@"px_deleted_messages_cache"] mutableCopy] ?: [NSMutableDictionary dictionary];
        for (id msg in messages) {
            NSString *msgId = nil;
            NSString *content = nil;
            if ([msg respondsToSelector:@selector(msgID)]) msgId = [msg msgID];
            if ([msg respondsToSelector:@selector(textContent)]) content = [msg textContent];
            if (msgId && content) cache[msgId] = @{@"text": content, @"ts": @([[NSDate date] timeIntervalSince1970])};
        }
        [[NSUserDefaults standardUserDefaults] setObject:cache forKey:@"px_deleted_messages_cache"];
    });
}

// Хук на удаление — помечаем сообщение как удалённое
- (void)revokeMessage:(id)message completion:(id)completion {
    if ([BHIManager deletedMessagesEnabled]) {
        NSString *msgId = [message respondsToSelector:@selector(msgID)] ? [message msgID] : nil;
        if (msgId) {
            NSMutableDictionary *cache = [[[NSUserDefaults standardUserDefaults] dictionaryForKey:@"px_deleted_messages_cache"] mutableCopy] ?: [NSMutableDictionary dictionary];
            if (cache[msgId]) {
                NSMutableDictionary *entry = [cache[msgId] mutableCopy];
                entry[@"deleted"] = @YES;
                cache[msgId] = entry;
                [[NSUserDefaults standardUserDefaults] setObject:cache forKey:@"px_deleted_messages_cache"];
            }
        }
    }
    %orig;
}
%end

// ═══════════════════════════════════════════════════════════════
// ОГОНЁК — хук на отправку, если пришло уведомление о времени
// При получении локального уведомления px_streak_reminder
// находим последние чаты и отправляем streak-сообщение
// ═══════════════════════════════════════════════════════════════
%hook AppDelegate (PXStreak)
- (void)userNotificationCenter:(id)center didReceiveNotificationResponse:(id)response withCompletionHandler:(void (^)(void))handler {
    %orig;
    if (![BHIManager streakAutoRenewEnabled]) return;
    UNNotificationResponse *r = response;
    if (![r.notification.request.identifier isEqualToString:@"px_streak_reminder"]) return;

    NSString *msg = [BHIManager streakMessageText];
    if (msg.length == 0) msg = @"🔥";

    // Получаем список конверсаций через TIMConversationManager и отправляем сообщение
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        id convMgr = [%c(TIMConversationManager) performSelector:@selector(sharedInstance)];
        NSArray *convList = [convMgr respondsToSelector:@selector(getConversationList)] ? [convMgr getConversationList] : nil;
        for (id conv in convList) {
            if ([conv respondsToSelector:@selector(conversationType)]) {
                // Отправляем только в C2C (личные) чаты
                NSInteger type = [[conv conversationType] integerValue];
                if (type == 1) { // C2C
                    id textMsg = [%c(TIMTextElem) new];
                    if ([textMsg respondsToSelector:@selector(setText:)]) [textMsg setText:msg];
                    id message = [%c(TIMMessage) new];
                    if ([message respondsToSelector:@selector(addElem:)]) [message addElem:textMsg];
                    [conv sendMessage:message succ:nil fail:nil];
                }
            }
        }
    });
}
%end


// ═══════════════════════════════════════════════════════════════
// 1. СКРЫТИЕ ВКЛАДКИ TAKO (AWESettingsNormalSectionViewModel)
//    Tako появляется как "tako" sectionIdentifier в настройках.
//    Убираем его полностью.
// ═══════════════════════════════════════════════════════════════
%hook AWESettingsBaseViewModel
- (NSArray *)sectionViewModelsArray {
    NSArray *orig = %orig;
    NSMutableArray *filtered = [NSMutableArray array];
    for (id vm in orig) {
        if ([vm respondsToSelector:@selector(sectionIdentifier)]) {
            NSString *sid = [(AWESettingsNormalSectionViewModel *)vm sectionIdentifier];
            if ([sid.lowercaseString containsString:@"tako"]) continue;
        }
        [filtered addObject:vm];
    }
    return filtered;
}
%end

// ═══════════════════════════════════════════════════════════════
// 2. СОХРАНЕНИЕ АВАТАРА ДОЛГИМ НАЖАТИЕМ (всегда включено)
//    Хукаем BDImageView.layoutSubviews — уже есть, но там за тумблером.
//    Убираем проверку тумблера — работает всегда.
// ═══════════════════════════════════════════════════════════════
%hook BDImageView (PXAlwaysSaveAvatar)
- (void)layoutSubviews {
    %orig;
    // Всегда добавляем long press для сохранения аватара
    BOOL alreadyAdded = NO;
    for (UIGestureRecognizer *gr in self.gestureRecognizers) {
        if ([gr isKindOfClass:[UILongPressGestureRecognizer class]] &&
            [NSStringFromSelector(gr.action) containsString:@"LongPress"]) {
            alreadyAdded = YES; break;
        }
    }
    if (!alreadyAdded) {
        [self addHandleLongPress];
    }
}
%end

// ═══════════════════════════════════════════════════════════════
// 3. УВЕЛИЧЕННЫЙ ЛИМИТ СИМВОЛОВ В КОММЕНТАРИЯХ (всегда)
//    UITextView maxLength — TikTok ставит 150, мы убираем ограничение.
// ═══════════════════════════════════════════════════════════════
%hook AWETextInputController (PXCommentLimit)
- (NSInteger)textMaximumLength {
    NSInteger orig = %orig;
    return MAX(orig, 2200); // Instagram-style max
}
%end

// ═══════════════════════════════════════════════════════════════
// 4. ТОЧНАЯ ДАТА И ВРЕМЯ ПУБЛИКАЦИИ (всегда)
//    AWEAwemeModel.createTime — уже используется в AWEUserWorkCollectionViewCell.
//    Добавляем также в лентовый просмотр через AWEFeedCellViewController.
// ═══════════════════════════════════════════════════════════════
%hook AWEFeedCellViewController (PXPublishDate)
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    AWEAwemeModel *model = self.model;
    if (!model.createTime) return;
    NSTimeInterval ts = [model.createTime doubleValue];
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:ts];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"dd.MM.yyyy HH:mm";
    NSString *dateStr = [fmt stringFromDate:date];

    // Добавляем лейбл если ещё нет
    UIView *root = self.view;
    if ([root viewWithTag:8877]) return;
    UILabel *dateLbl = [[UILabel alloc] init];
    dateLbl.tag = 8877;
    dateLbl.text = dateStr;
    dateLbl.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    dateLbl.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.85];
    dateLbl.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.35];
    dateLbl.layer.cornerRadius = 6;
    dateLbl.clipsToBounds = YES;
    dateLbl.translatesAutoresizingMaskIntoConstraints = NO;
    dateLbl.textAlignment = NSTextAlignmentCenter;
    [root addSubview:dateLbl];
    [NSLayoutConstraint activateConstraints:@[
        [dateLbl.topAnchor constraintEqualToAnchor:root.safeAreaLayoutGuide.topAnchor constant:8],
        [dateLbl.leadingAnchor constraintEqualToAnchor:root.leadingAnchor constant:12],
        [dateLbl.heightAnchor constraintEqualToConstant:22],
        [dateLbl.widthAnchor constraintGreaterThanOrEqualToConstant:120],
    ]];
}
%end

// ═══════════════════════════════════════════════════════════════
// 5. КОПИРОВАНИЕ КОММЕНТАРИЯ БЕЗ @USERNAME (всегда)
//    Перехватываем long-press на AWECommentPanelCell, копируем только текст.
// ═══════════════════════════════════════════════════════════════
%hook AWECommentPanelCell (PXCopyNoAt)
- (void)longPressGestureAction:(UILongPressGestureRecognizer *)gr {
    %orig; // показываем оригинальное меню
    // Патчим UIPasteboard сразу после: убираем @mention если есть
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *text = [UIPasteboard generalPasteboard].string;
        if (text) {
            // Убираем все @слова из начала строки
            NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"@\\w+" options:0 error:nil];
            NSString *clean = [re stringByReplacingMatchesInString:text options:0 range:NSMakeRange(0, text.length) withTemplate:@""];
            clean = [clean stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (clean.length > 0) [UIPasteboard generalPasteboard].string = clean;
        }
    });
}
%end

// ═══════════════════════════════════════════════════════════════
// 6. СКРЫТИЕ РЕКОМЕНДАЦИЙ АККАУНТОВ (всегда)
//    isUserRecommendBigCard — флаг в AWEAwemeModel для карточек «подпишитесь».
// ═══════════════════════════════════════════════════════════════
%hook AWEAwemeModel (PXHideRecommend)
- (BOOL)isUserRecommendBigCard {
    return NO; // всегда скрываем карточки рекомендаций
}
%end

// ═══════════════════════════════════════════════════════════════
// 7. ОБВОДКА ИСТОРИЙ (применяем сохранённый цвет)
//    Хукаем AWEStoryBubbleView или TTKFriendTabStoryAvatarView.
//    Используем класс-перебор по имени т.к. точный класс не в хедерах.
// ═══════════════════════════════════════════════════════════════
%hook UIView (PXStoryBorder)
- (void)layoutSubviews {
    %orig;
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"px_story_border_enabled"]) return;
    NSString *cls = NSStringFromClass([self class]);
    if ([cls containsString:@"StoryBubble"] || [cls containsString:@"StoryAvatar"] || [cls containsString:@"FriendStory"]) {
        NSData *colorData = [[NSUserDefaults standardUserDefaults] objectForKey:@"px_story_border_color"];
        UIColor *borderColor = colorData
            ? [NSKeyedUnarchiver unarchivedObjectOfClass:[UIColor class] fromData:colorData error:nil]
            : [UIColor systemPinkColor];
        self.layer.borderColor = (borderColor ?: [UIColor systemPinkColor]).CGColor;
        self.layer.borderWidth = 2.5;
        self.layer.cornerRadius = self.bounds.size.height / 2.0;
    }
}
%end

// ═══════════════════════════════════════════════════════════════
// 8. ФИЛЬТР ПО ДЛИТЕЛЬНОСТИ (если включён тумблер)
// ═══════════════════════════════════════════════════════════════
%hook AWEAwemeModel (PXDurationFilter)
- (id)initWithDictionary:(id)arg1 error:(id *)arg2 {
    id obj = %orig;
    if (!obj) return obj;
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"px_duration_filter_enabled"]) return obj;
    double dur = [[(AWEAwemeModel *)obj video].duration doubleValue] / 1000.0; // ms → s
    double minD = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_duration_min"] ?: 15;
    double maxD = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_duration_max"] ?: 3600;
    if (dur > 0 && (dur < minD || dur > maxD)) return nil;
    return obj;
}
%end

// ═══════════════════════════════════════════════════════════════
// 9. ЧЁРНЫЙ СПИСОК СЛОВ (всегда)
// ═══════════════════════════════════════════════════════════════
%hook AWEAwemeModel (PXWordBlacklist)
- (id)init {
    id obj = %orig;
    if (!obj) return obj;
    NSArray *blacklist = [[NSUserDefaults standardUserDefaults] arrayForKey:@"px_word_blacklist"];
    if (!blacklist.count) return obj;
    // Получаем desc через KVC т.к. нет в хедерах
    NSString *desc = [(AWEAwemeModel *)obj valueForKeyPath:@"descriptionString"] ?:
                     [(AWEAwemeModel *)obj valueForKeyPath:@"desc"] ?:
                     [(AWEAwemeModel *)obj valueForKeyPath:@"videoDescription"] ?: @"";
    NSString *lower = desc.lowercaseString;
    for (NSString *word in blacklist) {
        if ([lower containsString:word.lowercaseString]) return nil;
    }
    return obj;
}
%end

// ═══════════════════════════════════════════════════════════════
// 10. КАСТОМНЫЙ ШРИФТ — подменяем системный если выбран
// ═══════════════════════════════════════════════════════════════
%hook UIFont (PXCustomFont)
+ (UIFont *)systemFontOfSize:(CGFloat)size {
    NSString *path = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_active_font_path"];
    if (!path.length) return %orig;
    // Загружаем шрифт
    static NSString *cachedFamily = nil;
    static dispatch_once_t onceToken;
    if (!cachedFamily) {
        NSURL *url = [NSURL fileURLWithPath:path];
        NSArray *descs = (__bridge_transfer NSArray *)CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
        if (descs.count > 0) {
            CTFontDescriptorRef desc = (__bridge CTFontDescriptorRef)descs[0];
            cachedFamily = (__bridge_transfer NSString *)CTFontDescriptorCopyAttribute(desc, kCTFontFamilyNameAttribute);
        }
    }
    if (cachedFamily) {
        UIFont *custom = [UIFont fontWithName:cachedFamily size:size];
        if (custom) return custom;
    }
    return %orig;
}
+ (UIFont *)boldSystemFontOfSize:(CGFloat)size {
    NSString *path = [[NSUserDefaults standardUserDefaults] stringForKey:@"px_active_font_path"];
    if (!path.length) return %orig;
    static NSString *cachedBoldFamily = nil;
    static dispatch_once_t onceToken;
    if (!cachedBoldFamily) {
        NSURL *url = [NSURL fileURLWithPath:path];
        NSArray *descs = (__bridge_transfer NSArray *)CTFontManagerCreateFontDescriptorsFromURL((__bridge CFURLRef)url);
        if (descs.count > 0) {
            CTFontDescriptorRef desc = (__bridge CTFontDescriptorRef)descs[0];
            cachedBoldFamily = (__bridge_transfer NSString *)CTFontDescriptorCopyAttribute(desc, kCTFontFamilyNameAttribute);
        }
    }
    if (cachedBoldFamily) {
        UIFont *custom = [UIFont fontWithName:[cachedBoldFamily stringByAppendingString:@"-Bold"] size:size]
                      ?: [UIFont fontWithName:cachedBoldFamily size:size];
        if (custom) return custom;
    }
    return %orig;
}
%end

// ═══════════════════════════════════════════════════════════════
// 11. ПРОВЕРКА ОГОНЬКА ПРИ ЗАПУСКЕ + АВТОМАТИЧЕСКАЯ ОТПРАВКА
// ═══════════════════════════════════════════════════════════════
%hook AppDelegate (PXStreakCheck)
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    BOOL result = %orig;
    if ([BHIManager streakAutoRenewEnabled]) {
        [self pxCheckAndRescheduleStreak];
    }
    return result;
}
%new - (void)pxCheckAndRescheduleStreak {
    // Проверяем когда последний раз отправляли
    NSTimeInterval lastSent = [[NSUserDefaults standardUserDefaults] doubleForKey:@"px_streak_last_sent"];
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    BOOL shouldSendNow = (now - lastSent) > 23.5 * 3600; // если прошло >23.5ч

    if (shouldSendNow && lastSent > 0) {
        // Отправляем сразу
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self pxSendStreakMessages];
        });
    }

    // Перепланируем уведомление
    NSString *timeStr = [BHIManager streakScheduledTime];
    NSArray *parts = [timeStr componentsSeparatedByString:@":"];
    NSInteger hour = [parts[0] integerValue];
    NSInteger min  = parts.count > 1 ? [parts[1] integerValue] : 0;

    [[UNUserNotificationCenter currentNotificationCenter] removePendingNotificationRequestsWithIdentifiers:@[@"px_streak_reminder"]];
    UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
    content.title = @"PXTok 🔥";
    content.body  = [BHIManager isRussian] ? @"Огонёк отправляется..." : @"Sending streak...";
    content.sound = [UNNotificationSound defaultSound];
    NSDateComponents *dc = [[NSDateComponents alloc] init];
    dc.hour = hour; dc.minute = min;
    UNCalendarNotificationTrigger *trigger = [UNCalendarNotificationTrigger triggerWithDateMatchingComponents:dc repeats:YES];
    UNNotificationRequest *req = [UNNotificationRequest requestWithIdentifier:@"px_streak_reminder" content:content trigger:trigger];
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:req withCompletionHandler:nil];
}
%new - (void)pxSendStreakMessages {
    NSString *msg = [BHIManager streakMessageText];
    if (!msg.length) msg = @"🔥";
    id convMgr = [%c(TIMConversationManager) performSelector:@selector(sharedInstance)];
    if (!convMgr) return;
    NSArray *convList = [convMgr respondsToSelector:@selector(getConversationList)] ? [convMgr getConversationList] : nil;
    for (id conv in convList) {
        NSInteger type = [[conv conversationType] integerValue];
        if (type == 1) { // C2C only
            id textElem = [%c(TIMTextElem) new];
            [textElem performSelector:@selector(setText:) withObject:msg];
            id message = [%c(TIMMessage) new];
            [message performSelector:@selector(addElem:) withObject:textElem];
            [conv performSelector:@selector(sendMessage:succ:fail:) withObject:message withObject:nil withObject:nil];
        }
    }
    [[NSUserDefaults standardUserDefaults] setDouble:[[NSDate date] timeIntervalSince1970] forKey:@"px_streak_last_sent"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
%end

// ═══════════════════════════════════════════════════════════════
// 12. УДАЛЁННЫЕ СООБЩЕНИЯ — отображение в чате
//     Хукаем ячейку сообщения: если сообщение в кэше как deleted → кастомный UI
// ═══════════════════════════════════════════════════════════════
// Попытка хука по имени класса (класс чат-ячейки TikTok)
%hook NSObject (PXIMCellHook)
- (void)pxCheckDeletedStateForMsgID:(NSString *)msgID inView:(UIView *)cell {
    if (![BHIManager deletedMessagesEnabled]) return;
    NSDictionary *cache = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"px_deleted_messages_cache"];
    NSDictionary *entry = cache[msgID];
    if (!entry || ![entry[@"deleted"] boolValue]) return;

    // Применяем прозрачность
    float opacity = [BHIManager deletedMessageOpacity];
    BOOL sameStyle = [BHIManager deletedMessageSameStyle];
    if (!sameStyle) cell.alpha = opacity;

    // Добавляем иконку корзины если ещё нет
    if ([cell viewWithTag:9321]) return;
    UILabel *trashIcon = [[UILabel alloc] init];
    trashIcon.tag = 9321;
    trashIcon.text = @"🗑";
    trashIcon.font = [UIFont systemFontOfSize:13];
    trashIcon.translatesAutoresizingMaskIntoConstraints = NO;
    trashIcon.userInteractionEnabled = YES;
    [cell addSubview:trashIcon];

    // Драг жест на корзину
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:trashIcon action:@selector(pxDragTrash:)];
    [trashIcon addGestureRecognizer:pan];

    // Тап на корзину — предпросмотр
    NSString *text = entry[@"text"] ?: @"";
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pxPreviewDeletedMessage:)];
    tap.accessibilityLabel = text;
    [trashIcon addGestureRecognizer:tap];

    [NSLayoutConstraint activateConstraints:@[
        [trashIcon.topAnchor constraintEqualToAnchor:cell.topAnchor constant:2],
        [trashIcon.leadingAnchor constraintEqualToAnchor:cell.leadingAnchor constant:4],
    ]];
}
%new - (void)pxPreviewDeletedMessage:(UITapGestureRecognizer *)gr {
    NSString *text = gr.accessibilityLabel ?: @"";
    BOOL ru = [BHIManager isRussian];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:(ru?@"Удалённое сообщение":@"Deleted Message") message:text preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    UIViewController *top = topMostController();
    [top presentViewController:alert animated:YES completion:nil];
}
%end

// Хук на ячейку сообщений TikTok IM
%hook UITableViewCell (PXIMDeletedCell)
- (void)layoutSubviews {
    %orig;
    NSString *cls = NSStringFromClass([self class]);
    // Имена ячеек сообщений TikTok содержат "Message" или "IM" или "Chat"
    if (!([cls containsString:@"Message"] || [cls containsString:@"IMCell"] || [cls containsString:@"ChatCell"])) return;
    if (![BHIManager deletedMessagesEnabled]) return;

    // Пробуем получить msgID через KVC
    NSString *msgID = [self valueForKeyPath:@"viewModel.message.msgID"]
                   ?: [self valueForKeyPath:@"message.msgID"]
                   ?: [self valueForKeyPath:@"model.msgID"];
    if (!msgID) return;
    [self pxCheckDeletedStateForMsgID:msgID inView:self];
}
%end


// Замена всех упоминаний BHTikTok++ в UI на PXTok (строки в алертах)
%hook NSString
- (BOOL)isEqualToString:(NSString *)aString {
    if ([aString isEqualToString:@"BHTikTok++ Settings"]) {
        return %orig(@"PXTok Settings");
    }
    return %orig;
}
%end


%ctor {
    jailbreakPaths = @[
        @"/Applications/Cydia.app", @"/Applications/blackra1n.app",
        @"/Applications/FakeCarrier.app", @"/Applications/Icy.app",
        @"/Applications/IntelliScreen.app", @"/Applications/MxTube.app",
        @"/Applications/RockApp.app", @"/Applications/SBSettings.app", @"/Applications/WinterBoard.app",
        @"/.cydia_no_stash", @"/.installed_unc0ver", @"/.bootstrapped_electra",
        @"/usr/libexec/cydia/firmware.sh", @"/usr/libexec/ssh-keysign", @"/usr/libexec/sftp-server",
        @"/usr/bin/ssh", @"/usr/bin/sshd", @"/usr/sbin/sshd",
        @"/var/lib/cydia", @"/var/lib/dpkg/info/mobilesubstrate.md5sums",
        @"/var/log/apt", @"/usr/share/jailbreak/injectme.plist", @"/usr/sbin/frida-server",
        @"/Library/MobileSubstrate/CydiaSubstrate.dylib", @"/Library/TweakInject",
        @"/Library/MobileSubstrate/MobileSubstrate.dylib", @"Library/MobileSubstrate/MobileSubstrate.dylib",
        @"/Library/MobileSubstrate/DynamicLibraries/LiveClock.plist", @"/Library/MobileSubstrate/DynamicLibraries/Veency.plist",
        @"/System/Library/LaunchDaemons/com.ikey.bbot.plist", @"/System/Library/LaunchDaemons/com.saurik.Cydia.Startup.plist", @"/System/Library/CoreServices/SystemVersion.plist",
        @"/private/var/mobile/Library/SBSettings/Themes", @"/private/var/lib/cydia",
        @"/private/var/tmp/cydia.log", @"/private/var/log/syslog",
        @"/private/var/cache/apt/", @"/private/var/lib/apt",
        @"/private/var/Users/", @"/private/var/stash",
        @"/usr/lib/libjailbreak.dylib", @"/usr/lib/libz.dylib",
        @"/usr/lib/system/introspectionNSZombieEnabled",
        @"/usr/lib/dyld",
        @"/jb/amfid_payload.dylib", @"/jb/libjailbreak.dylib",
        @"/jb/jailbreakd.plist", @"/jb/offsets.plist",
        @"/jb/lzma",
        @"/hmd_tmp_file",
        @"/etc/ssh/sshd_config", @"/etc/apt/undecimus/undecimus.list",
        @"/etc/apt/sources.list.d/sileo.sources", @"/etc/apt/sources.list.d/electra.list",
        @"/etc/apt", @"/etc/ssl/certs", @"/etc/ssl/cert.pem",
        @"/bin/sh", @"/bin/bash",
    ];
    %init;
}
